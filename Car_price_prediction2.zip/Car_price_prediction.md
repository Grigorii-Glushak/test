# Определение стоимости автомобилей

***Описание проекта:*** 

Сервис по продаже автомобилей с пробегом «Не бит, не крашен» разрабатывает приложение для привлечения новых клиентов. В нём можно быстро узнать рыночную стоимость своего автомобиля. В вашем распоряжении исторические данные: технические характеристики, комплектации и цены автомобилей. Вам нужно построить модель для определения стоимости. 

*Заказчику важны:*

- качество предсказания;
- скорость предсказания;
- время обучения.

Чтобы усилить исследование, мы не будем ограничиваться градиентным бустингом. Попробуем более простые модели — иногда они работают лучше. Эти редкие случаи легко пропустить, если всегда применять только бустинг. 
Поэкспериментируем и сравним характеристики моделей: время обучения, время предсказания, точность результата. За основу возьмём метрику RMSE. И значение не более 2500.

***Описание данных:***

*Признаки:*
- `DateCrawled` — дата скачивания анкеты из базы
- `VehicleType` — тип автомобильного кузова
- `RegistrationYear` — год регистрации автомобиля
- `Gearbox` — тип коробки передач
- `Power` — мощность (л. с.)
- `Model` — модель автомобиля
- `Kilometer` — пробег (км)
- `RegistrationMonth` — месяц регистрации автомобиля
- `FuelType` — тип топлива
- `Brand` — марка автомобиля
- `Repaired` — была машина в ремонте или нет
- `DateCreated` — дата создания анкеты
- `NumberOfPictures` — количество фотографий автомобиля
- `PostalCode` — почтовый индекс владельца анкеты (пользователя)
- `LastSeen` — дата последней активности пользователя

*Целевой признак:*
- `Price` — цена (евро)

***План работы над проектом:***

1. Подготовка данных
2. Обучение моделей
3. Анализ моделей
4. Общий вывод

## Подготовка данных


```python
# установим последнюю версию scikit-learn, если она не установлена
# теперь для OneHotEncoder работает одновремеено drop='first' и handle_unknown='ignore'
# !pip install scikit-learn==1.1.3

# и установим библиотеку lightgbm если она не установлена
# !pip install lightgbm
```


```python
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import lightgbm
import warnings
import re

from sklearn.tree import DecisionTreeRegressor
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import (
    train_test_split,
    GridSearchCV)

from sklearn.metrics import mean_squared_error

from sklearn.preprocessing import (
    StandardScaler, 
    OneHotEncoder,
    OrdinalEncoder)

warnings.filterwarnings("ignore")
sns.set(rc={'figure.figsize': (15,7)})
RD_ST=12345
```


```python
def start(df):
        df.info()
        print('\n',df.describe())
        display(df.sample(5))
        print('Количество пропусков в таблице:', df.isna().sum().sum(), '\n')
        print(df.isna().sum(), '\n')
        print('Количество дубликатов в таблице:',  df.duplicated().sum())
        df.hist(figsize=(15, 20));
```


```python
data = pd.read_csv('autos.csv')
start(data)
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 354369 entries, 0 to 354368
    Data columns (total 16 columns):
     #   Column             Non-Null Count   Dtype 
    ---  ------             --------------   ----- 
     0   DateCrawled        354369 non-null  object
     1   Price              354369 non-null  int64 
     2   VehicleType        316879 non-null  object
     3   RegistrationYear   354369 non-null  int64 
     4   Gearbox            334536 non-null  object
     5   Power              354369 non-null  int64 
     6   Model              334664 non-null  object
     7   Kilometer          354369 non-null  int64 
     8   RegistrationMonth  354369 non-null  int64 
     9   FuelType           321474 non-null  object
     10  Brand              354369 non-null  object
     11  Repaired           283215 non-null  object
     12  DateCreated        354369 non-null  object
     13  NumberOfPictures   354369 non-null  int64 
     14  PostalCode         354369 non-null  int64 
     15  LastSeen           354369 non-null  object
    dtypes: int64(7), object(9)
    memory usage: 43.3+ MB
    
                    Price  RegistrationYear          Power      Kilometer  \
    count  354369.000000     354369.000000  354369.000000  354369.000000   
    mean     4416.656776       2004.234448     110.094337  128211.172535   
    std      4514.158514         90.227958     189.850405   37905.341530   
    min         0.000000       1000.000000       0.000000    5000.000000   
    25%      1050.000000       1999.000000      69.000000  125000.000000   
    50%      2700.000000       2003.000000     105.000000  150000.000000   
    75%      6400.000000       2008.000000     143.000000  150000.000000   
    max     20000.000000       9999.000000   20000.000000  150000.000000   
    
           RegistrationMonth  NumberOfPictures     PostalCode  
    count      354369.000000          354369.0  354369.000000  
    mean            5.714645               0.0   50508.689087  
    std             3.726421               0.0   25783.096248  
    min             0.000000               0.0    1067.000000  
    25%             3.000000               0.0   30165.000000  
    50%             6.000000               0.0   49413.000000  
    75%             9.000000               0.0   71083.000000  
    max            12.000000               0.0   99998.000000  
    


<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>DateCrawled</th>
      <th>Price</th>
      <th>VehicleType</th>
      <th>RegistrationYear</th>
      <th>Gearbox</th>
      <th>Power</th>
      <th>Model</th>
      <th>Kilometer</th>
      <th>RegistrationMonth</th>
      <th>FuelType</th>
      <th>Brand</th>
      <th>Repaired</th>
      <th>DateCreated</th>
      <th>NumberOfPictures</th>
      <th>PostalCode</th>
      <th>LastSeen</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>128792</th>
      <td>2016-03-30 01:56:29</td>
      <td>4900</td>
      <td>bus</td>
      <td>2001</td>
      <td>manual</td>
      <td>102</td>
      <td>transporter</td>
      <td>150000</td>
      <td>7</td>
      <td>gasoline</td>
      <td>volkswagen</td>
      <td>no</td>
      <td>2016-03-30 00:00:00</td>
      <td>0</td>
      <td>44793</td>
      <td>2016-04-06 19:17:48</td>
    </tr>
    <tr>
      <th>152822</th>
      <td>2016-03-20 14:25:37</td>
      <td>12000</td>
      <td>sedan</td>
      <td>1985</td>
      <td>manual</td>
      <td>72</td>
      <td>other</td>
      <td>90000</td>
      <td>7</td>
      <td>gasoline</td>
      <td>mercedes_benz</td>
      <td>no</td>
      <td>2016-03-20 00:00:00</td>
      <td>0</td>
      <td>35633</td>
      <td>2016-04-06 23:45:39</td>
    </tr>
    <tr>
      <th>172264</th>
      <td>2016-03-13 23:52:41</td>
      <td>3000</td>
      <td>convertible</td>
      <td>2005</td>
      <td>manual</td>
      <td>75</td>
      <td>2_reihe</td>
      <td>125000</td>
      <td>7</td>
      <td>lpg</td>
      <td>peugeot</td>
      <td>NaN</td>
      <td>2016-03-13 00:00:00</td>
      <td>0</td>
      <td>24103</td>
      <td>2016-03-19 18:46:40</td>
    </tr>
    <tr>
      <th>344903</th>
      <td>2016-03-13 11:41:49</td>
      <td>9800</td>
      <td>small</td>
      <td>2012</td>
      <td>manual</td>
      <td>115</td>
      <td>2_reihe</td>
      <td>70000</td>
      <td>9</td>
      <td>gasoline</td>
      <td>peugeot</td>
      <td>no</td>
      <td>2016-03-13 00:00:00</td>
      <td>0</td>
      <td>53111</td>
      <td>2016-04-06 15:17:25</td>
    </tr>
    <tr>
      <th>342394</th>
      <td>2016-03-07 20:52:31</td>
      <td>555</td>
      <td>sedan</td>
      <td>1993</td>
      <td>manual</td>
      <td>90</td>
      <td>80</td>
      <td>150000</td>
      <td>3</td>
      <td>petrol</td>
      <td>audi</td>
      <td>no</td>
      <td>2016-03-07 00:00:00</td>
      <td>0</td>
      <td>91785</td>
      <td>2016-03-16 05:16:22</td>
    </tr>
  </tbody>
</table>
</div>


    Количество пропусков в таблице: 181077 
    
    DateCrawled              0
    Price                    0
    VehicleType          37490
    RegistrationYear         0
    Gearbox              19833
    Power                    0
    Model                19705
    Kilometer                0
    RegistrationMonth        0
    FuelType             32895
    Brand                    0
    Repaired             71154
    DateCreated              0
    NumberOfPictures         0
    PostalCode               0
    LastSeen                 0
    dtype: int64 
    
    Количество дубликатов в таблице: 4
    


    
![png](output_11_3.png)
    


По первому взгляду мы обнаружили `4 дубликата`, много пропусков в разных колонках. Так же гистограммы показали нам некоторые особенности признаков. Например по столбцу киллометража видно, что большинство машин очень не новы, а с большим пробегом. Фотографий в объявлениях очень мало или нет вовсе, а в признаках о годе регистрации и мощности авто есть много выбросов. Так же в столбце цены много машин имеет очень маленькую стоимость или равна нулю. В дальнейшем обязательно обратим на это внимание.

И так, приступим. Для начала переименуем столбцы в привычный нам вид и приведём всё к нижнему регистру.


```python
data.columns = data.columns.str.replace(r"([A-Z])", r" \1").str.lower().str.replace(' ', '_').str[1:]
data.head(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>date_crawled</th>
      <th>price</th>
      <th>vehicle_type</th>
      <th>registration_year</th>
      <th>gearbox</th>
      <th>power</th>
      <th>model</th>
      <th>kilometer</th>
      <th>registration_month</th>
      <th>fuel_type</th>
      <th>brand</th>
      <th>repaired</th>
      <th>date_created</th>
      <th>number_of_pictures</th>
      <th>postal_code</th>
      <th>last_seen</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2016-03-24 11:52:17</td>
      <td>480</td>
      <td>NaN</td>
      <td>1993</td>
      <td>manual</td>
      <td>0</td>
      <td>golf</td>
      <td>150000</td>
      <td>0</td>
      <td>petrol</td>
      <td>volkswagen</td>
      <td>NaN</td>
      <td>2016-03-24 00:00:00</td>
      <td>0</td>
      <td>70435</td>
      <td>2016-04-07 03:16:57</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2016-03-24 10:58:45</td>
      <td>18300</td>
      <td>coupe</td>
      <td>2011</td>
      <td>manual</td>
      <td>190</td>
      <td>NaN</td>
      <td>125000</td>
      <td>5</td>
      <td>gasoline</td>
      <td>audi</td>
      <td>yes</td>
      <td>2016-03-24 00:00:00</td>
      <td>0</td>
      <td>66954</td>
      <td>2016-04-07 01:46:50</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2016-03-14 12:52:21</td>
      <td>9800</td>
      <td>suv</td>
      <td>2004</td>
      <td>auto</td>
      <td>163</td>
      <td>grand</td>
      <td>125000</td>
      <td>8</td>
      <td>gasoline</td>
      <td>jeep</td>
      <td>NaN</td>
      <td>2016-03-14 00:00:00</td>
      <td>0</td>
      <td>90480</td>
      <td>2016-04-05 12:47:46</td>
    </tr>
  </tbody>
</table>
</div>




```python
data.columns = [re.sub(r'(?<=[a-z])(?=[A-Z0-9])|(?<=[A-Z0-9])(?=[A-Z][a-z\d])', '_', col).lower()
                for col in data.columns]
data.head(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>date_crawled</th>
      <th>price</th>
      <th>vehicle_type</th>
      <th>registration_year</th>
      <th>gearbox</th>
      <th>power</th>
      <th>model</th>
      <th>kilometer</th>
      <th>registration_month</th>
      <th>fuel_type</th>
      <th>brand</th>
      <th>repaired</th>
      <th>date_created</th>
      <th>number_of_pictures</th>
      <th>postal_code</th>
      <th>last_seen</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2016-03-24 11:52:17</td>
      <td>480</td>
      <td>NaN</td>
      <td>1993</td>
      <td>manual</td>
      <td>0</td>
      <td>golf</td>
      <td>150000</td>
      <td>0</td>
      <td>petrol</td>
      <td>volkswagen</td>
      <td>NaN</td>
      <td>2016-03-24 00:00:00</td>
      <td>0</td>
      <td>70435</td>
      <td>2016-04-07 03:16:57</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2016-03-24 10:58:45</td>
      <td>18300</td>
      <td>coupe</td>
      <td>2011</td>
      <td>manual</td>
      <td>190</td>
      <td>NaN</td>
      <td>125000</td>
      <td>5</td>
      <td>gasoline</td>
      <td>audi</td>
      <td>yes</td>
      <td>2016-03-24 00:00:00</td>
      <td>0</td>
      <td>66954</td>
      <td>2016-04-07 01:46:50</td>
    </tr>
    <tr>
      <th>2</th>
      <td>2016-03-14 12:52:21</td>
      <td>9800</td>
      <td>suv</td>
      <td>2004</td>
      <td>auto</td>
      <td>163</td>
      <td>grand</td>
      <td>125000</td>
      <td>8</td>
      <td>gasoline</td>
      <td>jeep</td>
      <td>NaN</td>
      <td>2016-03-14 00:00:00</td>
      <td>0</td>
      <td>90480</td>
      <td>2016-04-05 12:47:46</td>
    </tr>
  </tbody>
</table>
</div>



Далее удалим из таблицы столбцы, которые *точно не понадобятся* нам для обучения моделей. (`date_crawled, registration_month, date_created, number_of_pictures, postal_code, last_seen`)


```python
data = data.drop(['date_crawled', 'registration_month', 'date_created', 'number_of_pictures',\
                  'postal_code', 'last_seen'], axis=1)
data.head(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>price</th>
      <th>vehicle_type</th>
      <th>registration_year</th>
      <th>gearbox</th>
      <th>power</th>
      <th>model</th>
      <th>kilometer</th>
      <th>fuel_type</th>
      <th>brand</th>
      <th>repaired</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>480</td>
      <td>NaN</td>
      <td>1993</td>
      <td>manual</td>
      <td>0</td>
      <td>golf</td>
      <td>150000</td>
      <td>petrol</td>
      <td>volkswagen</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1</th>
      <td>18300</td>
      <td>coupe</td>
      <td>2011</td>
      <td>manual</td>
      <td>190</td>
      <td>NaN</td>
      <td>125000</td>
      <td>gasoline</td>
      <td>audi</td>
      <td>yes</td>
    </tr>
    <tr>
      <th>2</th>
      <td>9800</td>
      <td>suv</td>
      <td>2004</td>
      <td>auto</td>
      <td>163</td>
      <td>grand</td>
      <td>125000</td>
      <td>gasoline</td>
      <td>jeep</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>



Удалили именно эти колонки так как от их показателей не зависит цена продаваемого авто. Например колонка с количеством фотографий. Стоимость не уменьшится если их не будет вовсе или не увеличится если их будет много. Так же и дата создания объявления или последний раз, когда продавец был на платформе. И так далее.

Первый взляд на данные показал, что есть `4 дубликата`. Посмотрим на их количество после удаления не нужных нам столбцов. Возможно появятся неявные дубликаты.


```python
data[data.duplicated()]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>price</th>
      <th>vehicle_type</th>
      <th>registration_year</th>
      <th>gearbox</th>
      <th>power</th>
      <th>model</th>
      <th>kilometer</th>
      <th>fuel_type</th>
      <th>brand</th>
      <th>repaired</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1117</th>
      <td>950</td>
      <td>small</td>
      <td>1999</td>
      <td>manual</td>
      <td>60</td>
      <td>polo</td>
      <td>150000</td>
      <td>petrol</td>
      <td>volkswagen</td>
      <td>no</td>
    </tr>
    <tr>
      <th>1396</th>
      <td>0</td>
      <td>NaN</td>
      <td>2000</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
      <td>150000</td>
      <td>NaN</td>
      <td>volvo</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>2169</th>
      <td>0</td>
      <td>coupe</td>
      <td>2002</td>
      <td>manual</td>
      <td>129</td>
      <td>c_klasse</td>
      <td>150000</td>
      <td>petrol</td>
      <td>mercedes_benz</td>
      <td>no</td>
    </tr>
    <tr>
      <th>2833</th>
      <td>1499</td>
      <td>small</td>
      <td>2001</td>
      <td>manual</td>
      <td>58</td>
      <td>corsa</td>
      <td>150000</td>
      <td>petrol</td>
      <td>opel</td>
      <td>no</td>
    </tr>
    <tr>
      <th>3025</th>
      <td>2800</td>
      <td>wagon</td>
      <td>2005</td>
      <td>NaN</td>
      <td>0</td>
      <td>touran</td>
      <td>150000</td>
      <td>gasoline</td>
      <td>volkswagen</td>
      <td>no</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>354352</th>
      <td>6500</td>
      <td>sedan</td>
      <td>2003</td>
      <td>auto</td>
      <td>145</td>
      <td>e_klasse</td>
      <td>150000</td>
      <td>gasoline</td>
      <td>mercedes_benz</td>
      <td>no</td>
    </tr>
    <tr>
      <th>354355</th>
      <td>4400</td>
      <td>sedan</td>
      <td>2008</td>
      <td>manual</td>
      <td>105</td>
      <td>leon</td>
      <td>150000</td>
      <td>gasoline</td>
      <td>seat</td>
      <td>no</td>
    </tr>
    <tr>
      <th>354358</th>
      <td>1490</td>
      <td>small</td>
      <td>1998</td>
      <td>manual</td>
      <td>50</td>
      <td>lupo</td>
      <td>150000</td>
      <td>petrol</td>
      <td>volkswagen</td>
      <td>no</td>
    </tr>
    <tr>
      <th>354359</th>
      <td>7900</td>
      <td>sedan</td>
      <td>2010</td>
      <td>manual</td>
      <td>140</td>
      <td>golf</td>
      <td>150000</td>
      <td>gasoline</td>
      <td>volkswagen</td>
      <td>no</td>
    </tr>
    <tr>
      <th>354363</th>
      <td>1150</td>
      <td>bus</td>
      <td>2000</td>
      <td>manual</td>
      <td>0</td>
      <td>zafira</td>
      <td>150000</td>
      <td>petrol</td>
      <td>opel</td>
      <td>no</td>
    </tr>
  </tbody>
</table>
<p>45040 rows × 10 columns</p>
</div>



Да, действительно. Около 45040 дубликата. Удалим эти строки из таблицы.


```python
data = data[~data.duplicated()]
data.shape[0]
```




    309329



Теперь будем рассматривать каждый признак отдельно. При наличии аномальных значений будем от них избавляться и решим вопрос с имеющимися пропусками в некоторых столбцах.

Первый признак `price`. Посторим гистограмму и подберём для неё такие настройки отображения, чтобы она была максимально показательна.


```python
data['price'].hist(bins=50);
```


    
![png](output_25_0.png)
    


Видим достаточно плавное изменение цены. Без резких всплесков. Но видно и то, что цена начинается с `0`. Поменяем масштаб графика.


```python
var1 = data.query('price < 1000')['price']
var2 = data.query('price > 5000')['price']

fig, ax = plt.subplots(1, 2, figsize = (20,8))
# fig.suptitle('Название', fontsize = 30, fontweight='bold')

ax[0].hist(var1, bins=25)
ax[0].set_title('Price < 1000')

ax[1].hist(var2, bins=25)
ax[1].set_title('Price > 5000')

plt.show()
```


    
![png](output_27_0.png)
    


Около `12000 продавцов` выставили `стоимость 0` или очень приближенную к `0`. Мы избавимся от этих данных, чтобы они не давали дополнительных искажений при обучении модели. Так же мы видим всплеск на `500`. Это популярная цена в данном диапазоне. Поэтому всё, что меньше `500` мы уберём из датасете. 


```python
data = data.query('price >= 500')
```

Далее признак `vehicle_type`. Это тип автомобильного кузова. При первичном осмотре данных в этом столце мы наблюдали `37490 пропуск`. Заполнить категориальный признак в нашем случае мы не имеем возможности, но и удалять такое количество данных так же мы не будем. Просто заполним значением `"other"`. Но для начала посмтрим уникальные значение на предмет неявных дубликатов.


```python
data['vehicle_type'].unique()
```




    array(['coupe', 'suv', 'small', 'sedan', 'convertible', 'bus', 'wagon',
           nan, 'other'], dtype=object)




```python
data['vehicle_type'] = data['vehicle_type'].fillna('other')
data['vehicle_type'].isna().sum()
```




    0



Отлично! Приступаем к признаку `registration_year`. Это год регистрации автомобиля. Пропусков нет, но посмотрим на уникальные значения столбца и построим график.


```python
data['registration_year'].sort_values().unique()
```




    array([1000, 1001, 1039, 1234, 1400, 1500, 1600, 1602, 1800, 1910, 1923,
           1925, 1927, 1928, 1929, 1930, 1931, 1932, 1933, 1934, 1935, 1936,
           1937, 1938, 1940, 1941, 1942, 1943, 1944, 1945, 1946, 1947, 1948,
           1949, 1950, 1951, 1952, 1953, 1954, 1955, 1956, 1957, 1958, 1959,
           1960, 1961, 1962, 1963, 1964, 1965, 1966, 1967, 1968, 1969, 1970,
           1971, 1972, 1973, 1974, 1975, 1976, 1977, 1978, 1979, 1980, 1981,
           1982, 1983, 1984, 1985, 1986, 1987, 1988, 1989, 1990, 1991, 1992,
           1993, 1994, 1995, 1996, 1997, 1998, 1999, 2000, 2001, 2002, 2003,
           2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014,
           2015, 2016, 2017, 2018, 2019, 2066, 2290, 2500, 2800, 2900, 3000,
           3200, 3700, 3800, 4000, 4100, 4500, 4800, 5000, 5300, 5555, 5911,
           6000, 7000, 7100, 7800, 8200, 8500, 8888, 9000, 9450, 9999],
          dtype=int64)




```python
data.query('registration_year >= 1980 & registration_year <= 2016')['registration_year'].hist(bins=50);
```


    
![png](output_35_0.png)
    


У нас много разный выбросов в этом столбце. Постоив график из более "адекватных лет", мы принимаем решение оставить только годы регистрации `с 1990 по 2016`. Это именно тот год, когда выли выгружены объявления и сформирована таблица.


```python
data = data.query('registration_year >= 1990 & registration_year <= 2016')
```

Далее `gearbox`. Это тип коробки передач. Так же проверим уникальные значения.


```python
data['gearbox'].unique()
```




    array(['manual', 'auto', nan], dtype=object)



Хорошо. Так как на начальном этапе в таблице было `19833` пропусков, то замени пустые значения `"unknown"`.


```python
data['gearbox'] = data['gearbox'].fillna('unknown')
data['gearbox'].isna().sum()
```




    0



Переходим к `power`. В этом столбце мощность авто (л. с.). Построим график, но уже масштаб будет брать такой, чтобы было понятно, так как при первоначальном ознакомлении с данными на графике было видно, что есть значительные аномалии.




```python
data.query('power < 2500')['power'].hist(bins=50);
```


    
![png](output_43_0.png)
    


И ещё увеличим масштаб, чтобы было видно, что происходит в районе `0`.


```python
var1 = data.query('power < 100')['power']
var2 = data.query('power > 250 & power < 500')['power']

fig, ax = plt.subplots(1, 2, figsize = (20,8))
# fig.suptitle('Название', fontsize = 30, fontweight='bold')

ax[0].hist(var1, bins=25)
ax[0].set_title('Power < 100')

ax[1].hist(var2, bins=25)
ax[1].set_title('Power > 250')

plt.show()
```


    
![png](output_45_0.png)
    


Отлично! Теперь прекрасно видно. Очень много авто с мощностью 0. Заполним их медианой по бренду. 


```python
data.loc[(data['power'] == 0), 'power'] = data.groupby('brand')['power'].median()
data[data['power'] == 0]['power'].count()
```




    0



Хорошо. Оставим в датафрейме только те машины, которые укладываются по мощности в диапазон `от 30 до 450`.


```python
data = data.loc[(data['power'] <= 450)]
```

Далее `model`. Это модель автомобиля. Как обычно посмотрим уникальные отсортированные значения, на поиск неявных дубликатов. И заполним пропуски на значение `"other"`. (в начале было замечено `19705` в столбце)


```python
data['model'].sort_values().unique()
```




    array(['100', '145', '147', '156', '159', '1_reihe', '1er', '200',
           '2_reihe', '300c', '3_reihe', '3er', '4_reihe', '500', '5_reihe',
           '5er', '601', '6_reihe', '6er', '7er', '80', '850', '90', '900',
           '9000', '911', 'a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'a8',
           'a_klasse', 'accord', 'agila', 'alhambra', 'almera', 'altea',
           'amarok', 'antara', 'arosa', 'astra', 'auris', 'avensis', 'aveo',
           'aygo', 'b_klasse', 'b_max', 'beetle', 'berlingo', 'bora',
           'boxster', 'bravo', 'c1', 'c2', 'c3', 'c4', 'c5', 'c_klasse',
           'c_max', 'c_reihe', 'caddy', 'calibra', 'captiva', 'carisma',
           'carnival', 'cayenne', 'cc', 'ceed', 'charade', 'cherokee',
           'citigo', 'civic', 'cl', 'clio', 'clk', 'clubman', 'colt', 'combo',
           'cooper', 'cordoba', 'corolla', 'corsa', 'cr_reihe', 'croma',
           'crossfire', 'cuore', 'cx_reihe', 'defender', 'delta', 'discovery',
           'doblo', 'ducato', 'duster', 'e_klasse', 'elefantino', 'eos',
           'escort', 'espace', 'exeo', 'fabia', 'fiesta', 'focus', 'forester',
           'forfour', 'fortwo', 'fox', 'freelander', 'fusion', 'g_klasse',
           'galant', 'galaxy', 'getz', 'gl', 'glk', 'golf', 'grand', 'i3',
           'i_reihe', 'ibiza', 'impreza', 'insignia', 'jazz', 'jetta',
           'jimny', 'juke', 'justy', 'ka', 'kadett', 'kaefer', 'kalina',
           'kalos', 'kangoo', 'kappa', 'kuga', 'laguna', 'lancer', 'lanos',
           'legacy', 'leon', 'lodgy', 'logan', 'lupo', 'lybra', 'm_klasse',
           'm_reihe', 'materia', 'matiz', 'megane', 'meriva', 'micra', 'mii',
           'modus', 'mondeo', 'move', 'musa', 'mustang', 'mx_reihe', 'navara',
           'niva', 'note', 'nubira', 'octavia', 'omega', 'one', 'other',
           'outlander', 'pajero', 'panda', 'passat', 'phaeton', 'picanto',
           'polo', 'primera', 'ptcruiser', 'punto', 'q3', 'q5', 'q7',
           'qashqai', 'r19', 'range_rover', 'range_rover_evoque',
           'range_rover_sport', 'rangerover', 'rav', 'rio', 'roadster',
           'roomster', 'rx_reihe', 's60', 's_klasse', 's_max', 's_type',
           'samara', 'sandero', 'santa', 'scenic', 'scirocco', 'seicento',
           'sharan', 'signum', 'sirion', 'sl', 'slk', 'sorento', 'spark',
           'spider', 'sportage', 'sprinter', 'stilo', 'superb', 'swift',
           'terios', 'tigra', 'tiguan', 'toledo', 'touareg', 'touran',
           'transit', 'transporter', 'tt', 'tucson', 'twingo', 'up', 'v40',
           'v50', 'v60', 'v70', 'v_klasse', 'vectra', 'verso', 'viano',
           'vito', 'vivaro', 'voyager', 'wrangler', 'x_reihe', 'x_trail',
           'x_type', 'xc_reihe', 'yaris', 'yeti', 'ypsilon', 'z_reihe',
           'zafira', nan], dtype=object)




```python
data['model'] = data['model'].fillna('other')
data['model'].isna().sum()
```




    0



Столбец `kilometer`. Это данные о пробеге (км). Пока первый признак в котором ничего не будем менять. Очень много машин, которые имеют пробег около `150000 км`. Но есть и те, которые не так много колесили по дорогам. Поэтому переходим к следующему столбцу.

Это `fuel_type` - тип топлива. Смотрим уникальные значение и заполним `32895` пропуска, которые были на начальном этапе.


```python
data['fuel_type'].sort_values().unique()
```




    array(['cng', 'electric', 'gasoline', 'hybrid', 'lpg', 'other', 'petrol',
           nan], dtype=object)




```python
data['fuel_type'] = data['fuel_type'].fillna('other')
data['fuel_type'].isna().sum()
```




    0



Далее `brand`. Это марка автомобиля. Пропусков нет, но посмотрим на уникальные отосортированые значения.


```python
data['brand'].sort_values().unique()
```




    array(['alfa_romeo', 'audi', 'bmw', 'chevrolet', 'chrysler', 'citroen',
           'dacia', 'daewoo', 'daihatsu', 'fiat', 'ford', 'honda', 'hyundai',
           'jaguar', 'jeep', 'kia', 'lada', 'lancia', 'land_rover', 'mazda',
           'mercedes_benz', 'mini', 'mitsubishi', 'nissan', 'opel', 'peugeot',
           'porsche', 'renault', 'rover', 'saab', 'seat', 'skoda', 'smart',
           'sonstige_autos', 'subaru', 'suzuki', 'toyota', 'trabant',
           'volkswagen', 'volvo'], dtype=object)



Отлично. Далее `repaired`. Это была машина в ремонте или нет? Очень много пропусков. Аж `71154` на начальном этапе.Удалить строки не можем, так как столбец важен для нас. Посмотрим сколько проехали авто, которые точно было в ремонте.


```python
data.query('repaired == "yes"')['kilometer'].hist();
```


    
![png](output_60_0.png)
    


По графику видно, что в основном те машины, что проехали больше 120000 киллометров, были в ремонте. Так и заполним пустые значения.


```python
data.loc[data['kilometer'] >= 120000, 'repaired'] = 'yes'
data.loc[data['kilometer'] < 120000, 'repaired'] = 'no'
data['repaired'].isna().sum()
```




    0



Обработали все признаки. Проверим на пропуски повторно наш датасет и посмотрим на его общее состояние.


```python
data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 235462 entries, 1 to 354368
    Data columns (total 10 columns):
     #   Column             Non-Null Count   Dtype  
    ---  ------             --------------   -----  
     0   price              235462 non-null  int64  
     1   vehicle_type       235462 non-null  object 
     2   registration_year  235462 non-null  int64  
     3   gearbox            235462 non-null  object 
     4   power              235462 non-null  float64
     5   model              235462 non-null  object 
     6   kilometer          235462 non-null  int64  
     7   fuel_type          235462 non-null  object 
     8   brand              235462 non-null  object 
     9   repaired           235462 non-null  object 
    dtypes: float64(1), int64(3), object(6)
    memory usage: 19.8+ MB
    


```python
data.isna().sum()
```




    price                0
    vehicle_type         0
    registration_year    0
    gearbox              0
    power                0
    model                0
    kilometer            0
    fuel_type            0
    brand                0
    repaired             0
    dtype: int64



Пропусков нет. Оставшихся данных вполне должно хватить для нашей задачи, с учётом того, что это уже подготовленные данные. Построим схему корреляции и посмотрим, вдруг у нас в признаках есть очень зависимые пары в количественных данных.


```python
sns.heatmap(data.corr());
```


    
![png](output_67_0.png)
    


Таких нет.

Следующим этапом будет разбиение таблицы на обучающую, валидационную и тестовые выборки. `(60|20|20)`


```python
features = data.drop('price', axis=1)
target = data['price']

features_train, features_valid, target_train, target_valid = train_test_split(
    features, target, test_size=0.4, random_state=12345)

features_test, features_valid, target_test, target_valid = train_test_split(
    features_valid, target_valid, test_size=0.5, random_state=123456)

print(features_train.shape[0])
print(features_valid.shape[0])
print(target_test.shape[0])
```

    141277
    47093
    47092
    

Взглянем одним глазком на обучающую выборку. У нас есть `6` категориальных признаков. И так как мы будем обучать разные модели, то для некоторых из них нужно закодировать категориальные признаки как однократный числовой массив. Используем `OneHotEncoder` для линейной модели. А для "дерева" будет использовать порядковое кодирование `OrdinalEncoder` (это позволит увеличить скорость обучения).

Для начала скопируем выборки, чтобы не менять исходные.


```python
features_train_OHE = features_train.copy()
features_valid_OHE = features_valid.copy()
features_test_OHE = features_test.copy()

features_train_OE = features_train.copy()
features_valid_OE = features_valid.copy()
features_test_OE = features_test.copy()
```


```python
features_train.sample(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>vehicle_type</th>
      <th>registration_year</th>
      <th>gearbox</th>
      <th>power</th>
      <th>model</th>
      <th>kilometer</th>
      <th>fuel_type</th>
      <th>brand</th>
      <th>repaired</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>298937</th>
      <td>sedan</td>
      <td>2003</td>
      <td>manual</td>
      <td>113.0</td>
      <td>megane</td>
      <td>150000</td>
      <td>petrol</td>
      <td>renault</td>
      <td>yes</td>
    </tr>
    <tr>
      <th>90682</th>
      <td>coupe</td>
      <td>2001</td>
      <td>manual</td>
      <td>147.0</td>
      <td>astra</td>
      <td>150000</td>
      <td>petrol</td>
      <td>opel</td>
      <td>yes</td>
    </tr>
    <tr>
      <th>180874</th>
      <td>sedan</td>
      <td>1999</td>
      <td>manual</td>
      <td>150.0</td>
      <td>bora</td>
      <td>150000</td>
      <td>petrol</td>
      <td>volkswagen</td>
      <td>yes</td>
    </tr>
  </tbody>
</table>
</div>



Подготовим модель для кодирования данных в `OneHotEncoder` и закодируем данные.


```python
ohe_features_ridge = features_train_OHE.select_dtypes(include='object').columns.to_list()

encoder_ohe = OneHotEncoder(drop='first', handle_unknown='ignore', sparse=False)
encoder_ohe.fit(features_train_OHE[ohe_features_ridge])

features_train_OHE[encoder_ohe.get_feature_names_out()] = encoder_ohe.transform(features_train_OHE[ohe_features_ridge])
features_train_OHE = features_train_OHE.drop(ohe_features_ridge, axis=1)

features_valid_OHE[encoder_ohe.get_feature_names_out()] = encoder_ohe.transform(features_valid_OHE[ohe_features_ridge])
features_valid_OHE = features_valid_OHE.drop(ohe_features_ridge, axis=1)

features_test_OHE[encoder_ohe.get_feature_names_out()] = encoder_ohe.transform(features_test_OHE[ohe_features_ridge])
features_test_OHE = features_test_OHE.drop(ohe_features_ridge, axis=1)
```


```python
features_train_OHE.sample(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>registration_year</th>
      <th>power</th>
      <th>kilometer</th>
      <th>vehicle_type_convertible</th>
      <th>vehicle_type_coupe</th>
      <th>vehicle_type_other</th>
      <th>vehicle_type_sedan</th>
      <th>vehicle_type_small</th>
      <th>vehicle_type_suv</th>
      <th>vehicle_type_wagon</th>
      <th>...</th>
      <th>brand_skoda</th>
      <th>brand_smart</th>
      <th>brand_sonstige_autos</th>
      <th>brand_subaru</th>
      <th>brand_suzuki</th>
      <th>brand_toyota</th>
      <th>brand_trabant</th>
      <th>brand_volkswagen</th>
      <th>brand_volvo</th>
      <th>repaired_yes</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>155937</th>
      <td>1991</td>
      <td>54.0</td>
      <td>125000</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>46190</th>
      <td>1999</td>
      <td>58.0</td>
      <td>150000</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>59700</th>
      <td>2003</td>
      <td>101.0</td>
      <td>150000</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>1.0</td>
    </tr>
  </tbody>
</table>
<p>3 rows × 303 columns</p>
</div>



Подготовим модель для кодирования данных в `OrdinalEncoder` и закодируем данные.


```python
OE_features_ridge = features_train_OE.select_dtypes(include='object').columns.to_list()

enc = OrdinalEncoder(handle_unknown='use_encoded_value', unknown_value=-1)
enc.fit(data[OE_features_ridge])

features_train_OE[OE_features_ridge] = enc.transform(features_train_OE[OE_features_ridge])
features_valid_OE[OE_features_ridge] = enc.transform(features_valid_OE[OE_features_ridge])
features_test_OE[OE_features_ridge] = enc.transform(features_test_OE[OE_features_ridge])
```


```python
features_train_OE.sample(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>vehicle_type</th>
      <th>registration_year</th>
      <th>gearbox</th>
      <th>power</th>
      <th>model</th>
      <th>kilometer</th>
      <th>fuel_type</th>
      <th>brand</th>
      <th>repaired</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>287444</th>
      <td>2.0</td>
      <td>1997</td>
      <td>1.0</td>
      <td>90.0</td>
      <td>215.0</td>
      <td>150000</td>
      <td>6.0</td>
      <td>24.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>24819</th>
      <td>7.0</td>
      <td>2001</td>
      <td>1.0</td>
      <td>136.0</td>
      <td>103.0</td>
      <td>150000</td>
      <td>4.0</td>
      <td>10.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>189284</th>
      <td>0.0</td>
      <td>2008</td>
      <td>1.0</td>
      <td>102.0</td>
      <td>221.0</td>
      <td>150000</td>
      <td>2.0</td>
      <td>38.0</td>
      <td>1.0</td>
    </tr>
  </tbody>
</table>
</div>



Теперь нам нужно стандартизировать данные для использования их линейной модели. Сделаем это при помощи `StandardScaler`.


```python
pd.options.mode.chained_assignment = None
numeric = features_train_OHE.select_dtypes(include='number').columns.to_list()

scaler = StandardScaler()
scaler.fit(features_train_OHE[numeric])

features_train_OHE[numeric] = scaler.transform(features_train_OHE[numeric])
features_valid_OHE[numeric] = scaler.transform(features_valid_OHE[numeric])
features_test_OHE[numeric] = scaler.transform(features_test_OHE[numeric])
```


```python
features_test_OHE.sample(3)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>registration_year</th>
      <th>power</th>
      <th>kilometer</th>
      <th>vehicle_type_convertible</th>
      <th>vehicle_type_coupe</th>
      <th>vehicle_type_other</th>
      <th>vehicle_type_sedan</th>
      <th>vehicle_type_small</th>
      <th>vehicle_type_suv</th>
      <th>vehicle_type_wagon</th>
      <th>...</th>
      <th>brand_skoda</th>
      <th>brand_smart</th>
      <th>brand_sonstige_autos</th>
      <th>brand_subaru</th>
      <th>brand_suzuki</th>
      <th>brand_toyota</th>
      <th>brand_trabant</th>
      <th>brand_volkswagen</th>
      <th>brand_volvo</th>
      <th>repaired_yes</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>218698</th>
      <td>-1.054633</td>
      <td>0.483610</td>
      <td>0.618392</td>
      <td>-0.267634</td>
      <td>-0.227101</td>
      <td>-0.210254</td>
      <td>-0.621163</td>
      <td>-0.529914</td>
      <td>-0.20335</td>
      <td>1.955769</td>
      <td>...</td>
      <td>-0.138367</td>
      <td>-0.13196</td>
      <td>-0.070717</td>
      <td>-0.048092</td>
      <td>-0.084687</td>
      <td>-0.124927</td>
      <td>-0.011598</td>
      <td>-0.506877</td>
      <td>-0.100332</td>
      <td>0.568389</td>
    </tr>
    <tr>
      <th>151741</th>
      <td>-0.686539</td>
      <td>-0.343417</td>
      <td>0.618392</td>
      <td>-0.267634</td>
      <td>-0.227101</td>
      <td>-0.210254</td>
      <td>-0.621163</td>
      <td>-0.529914</td>
      <td>-0.20335</td>
      <td>-0.511308</td>
      <td>...</td>
      <td>-0.138367</td>
      <td>-0.13196</td>
      <td>-0.070717</td>
      <td>-0.048092</td>
      <td>-0.084687</td>
      <td>-0.124927</td>
      <td>-0.011598</td>
      <td>-0.506877</td>
      <td>-0.100332</td>
      <td>0.568389</td>
    </tr>
    <tr>
      <th>96869</th>
      <td>-1.606774</td>
      <td>-0.174253</td>
      <td>0.618392</td>
      <td>-0.267634</td>
      <td>-0.227101</td>
      <td>-0.210254</td>
      <td>1.609884</td>
      <td>-0.529914</td>
      <td>-0.20335</td>
      <td>-0.511308</td>
      <td>...</td>
      <td>-0.138367</td>
      <td>-0.13196</td>
      <td>-0.070717</td>
      <td>-0.048092</td>
      <td>-0.084687</td>
      <td>-0.124927</td>
      <td>-0.011598</td>
      <td>-0.506877</td>
      <td>-0.100332</td>
      <td>0.568389</td>
    </tr>
  </tbody>
</table>
<p>3 rows × 303 columns</p>
</div>



**Вывод:** В начале работы мы познакомились с данными. И провели предобработку, прежде чем обучать модели. Что именно было сделано:
- переименовали столбцы в привычный нам вид и привели всё к нижнему регистру;
- удалили из таблицы столбцы, которые *точно не понадобятся* нам для обучения моделей. (`date_crawled, registration_month, date_created, number_of_pictures, postal_code, last_seen`);
- было найдены `45040` дубликата и удалены и таблицы;
- в столбце `price` около `12000` продавцов выставили стоимость `0` или очень приближенную к `0`. Поэтому всё, что меньше `500` евро мы убрали из датасете, чтобы они не давали дополнительных искажений при обучении моделей;
- в признаке `vehicle_type` (тип автомобильного кузова) при первичном осмотре данных в этом столбце мы наблюдали `37490 пропуск`. Заполнить категориальный признак в нашем случае мы не имели возможности, но и удалять такое количество данных так же мы не стали. Просто заполнили значением `"other"`;
- по таму же принципу заполнили пропуски значением `"other"` в столбцах `model, fuel_type`. `gearbox` - в этом столбце пропуски заменили на `"unknown"`; 
- а в признаке по ремонту (`repaired`), заменили пропуски у всех машин, что имеют пробег более `120000` на `"yes"`, у другихх на `"no"` соответственно;
- в признаке `registration_year`. Это год регистрации автомобиля. Пропусков не было, но мы заметили разные выбросы в этом столбце. Постоив график, мы приняли решение оставить только годы регистрации `с 1990 по 2016` так как последний год это год выгрузки объявления и создания таблицы;
- `power`. В этом столбце мощность авто (л. с.) мы оставили в датафрейме только те машины, которые укладываются по мощности в диапазон `от 40 до 450`. Были значения и в райне `0`  мы из заменили на медиану по брендам;
- далее мы разбили таблицу на обучающую, валидационную и тестовые выборки. `(60|20|20)`
- у нас `6` категориальных признаков. И так как мы будем обучать разные модели, то для некоторых из них нужно закодировать категориальные признаки как однократный числовой массив. Используем `OneHotEncoder` для линейной модели. А для моеделей решающего дерева будем использовать порядковое кодирование `OrdinalEncoder` (это позволит увеличить скорость обучения).
- после кодирования мы стандартизировали данные для использования их линейной моделью. Сделали это при помощи `StandardScaler`.

## Обучение моделей

Обучим модели и найдём лучшие гиперпараметры для них. Первой моделью будет линейная, а именно `LinearRegression`.


```python
%%time

model_LR = LinearRegression().fit(features_train_OHE, target_train)

predictions_valid = model_LR.predict(features_valid_OHE)

best_score_train_LR = round(mean_squared_error(target_valid, predictions_valid)**0.5)
print('RMSE модели:', best_score_train_LR)
```

    RMSE модели: 2384
    Wall time: 3.11 s
    

Вторая модель будет древовидного типа, а именно `DecisionTreeRegressor`.


```python
%%time 
model_DTR = DecisionTreeRegressor(random_state=RD_ST)

param_grid = {'max_depth': range (2, 20, 2)}

grid = GridSearchCV(model_DTR, param_grid, cv=5, n_jobs=-1, scoring='neg_root_mean_squared_error')
grid.fit(features_train_OE, target_train)

best_param_train_DTR = grid.best_params_
best_score_train_DTR = round(grid.best_score_ * -1)

print('Параметры лучшей модели:', best_param_train_DTR)
print('RMSE лучшей модели:', best_score_train_DTR)
```

    Параметры лучшей модели: {'max_depth': 12}
    RMSE лучшей модели: 1886
    Wall time: 4.89 s
    

И теперь модель с бустингом. `LightGBM`.


```python
%%time 
model_LGB = lightgbm.LGBMRegressor(random_state=RD_ST)

param_grid = {'n_estimators': range (50, 500, 50),
              'num_leaves': range (20, 200, 20)}

grid = GridSearchCV(model_LGB, param_grid, cv=5, n_jobs=-1, scoring='neg_root_mean_squared_error')
grid.fit(features_train_OE, target_train)

best_param_train_LGB = grid.best_params_
best_score_train_LGB = round(grid.best_score_ * -1)

print('Параметры лучшей модели:', best_param_train_LGB)
print('RMSE лучшей модели:', best_score_train_LGB)
```

    Параметры лучшей модели: {'n_estimators': 450, 'num_leaves': 120}
    RMSE лучшей модели: 1569
    Wall time: 4min 56s
    

**Вывод:** Мы обучили `3 разные модели` и нашли лучшие гиперпараметры для них.

1 модель `LinearRegression` (RMSE модели: `{{best_score_train_LR}}`)

2 модель `DecisionTreeRegressor` (RMSE модели: `{{best_score_train_DTR}}`) 
- Параметры лучшей модели: {{best_param_train_DTR}}

3 модель `LightGBM` (RMSE модели: `{{best_score_train_LGB}}`) 
- Параметры лучшей модели: {{best_param_train_LGB}}

## Анализ моделей

Теперь имея параметры для моделей обучим их заново, замерим скорость обучения и скорость предсказаний, а так же качество предсказаний.

Первая `LinearRegression`


```python
%%time
model_LR = LinearRegression()
model_LR.fit(features_train_OHE, target_train)
```

    Wall time: 4.38 s
    




<style>#sk-container-id-1 {color: black;background-color: white;}#sk-container-id-1 pre{padding: 0;}#sk-container-id-1 div.sk-toggleable {background-color: white;}#sk-container-id-1 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-1 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-1 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-1 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-1 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-1 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-1 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-1 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-1 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-1 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-1 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-1 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-1 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-1 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-1 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-1 div.sk-item {position: relative;z-index: 1;}#sk-container-id-1 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-1 div.sk-item::before, #sk-container-id-1 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-1 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-1 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-1 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-1 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-1 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-1 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-1 div.sk-label-container {text-align: center;}#sk-container-id-1 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-1 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-1" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>LinearRegression()</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-1" type="checkbox" checked><label for="sk-estimator-id-1" class="sk-toggleable__label sk-toggleable__label-arrow">LinearRegression</label><div class="sk-toggleable__content"><pre>LinearRegression()</pre></div></div></div></div></div>




```python
%%time
predictions_valid = model_LR.predict(features_valid_OHE)
```

    Wall time: 20.9 ms
    


```python
RMSE_valid_LR = round(mean_squared_error(target_valid, predictions_valid)**0.5)
print('RMSE модели:', RMSE_valid_LR)
```

    RMSE модели: 2384
    

Вторая `DecisionTreeRegressor`


```python
%%time
model_DTR = DecisionTreeRegressor(**best_param_train_DTR, random_state=RD_ST)
model_DTR.fit(features_train_OE, target_train)
```

    Wall time: 291 ms
    




<style>#sk-container-id-2 {color: black;background-color: white;}#sk-container-id-2 pre{padding: 0;}#sk-container-id-2 div.sk-toggleable {background-color: white;}#sk-container-id-2 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-2 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-2 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-2 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-2 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-2 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-2 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-2 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-2 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-2 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-2 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-2 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-2 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-2 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-2 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-2 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-2 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-2 div.sk-item {position: relative;z-index: 1;}#sk-container-id-2 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-2 div.sk-item::before, #sk-container-id-2 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-2 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-2 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-2 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-2 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-2 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-2 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-2 div.sk-label-container {text-align: center;}#sk-container-id-2 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-2 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-2" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>DecisionTreeRegressor(max_depth=12, random_state=12345)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-2" type="checkbox" checked><label for="sk-estimator-id-2" class="sk-toggleable__label sk-toggleable__label-arrow">DecisionTreeRegressor</label><div class="sk-toggleable__content"><pre>DecisionTreeRegressor(max_depth=12, random_state=12345)</pre></div></div></div></div></div>




```python
%%time
predictions_valid = model_DTR.predict(features_valid_OE)
```

    Wall time: 15 ms
    


```python
RMSE_valid_DTR = round(mean_squared_error(target_valid, predictions_valid)**0.5)
print('RMSE модели:', RMSE_valid_DTR)
```

    RMSE модели: 1867
    

Третья модель `LightGBM`.


```python
%%time
model_LGB = lightgbm.LGBMRegressor(**best_param_train_LGB, random_state=RD_ST)
model_LGB.fit(features_train_OE, target_train)
```

    Wall time: 2.12 s
    




<style>#sk-container-id-4 {color: black;background-color: white;}#sk-container-id-4 pre{padding: 0;}#sk-container-id-4 div.sk-toggleable {background-color: white;}#sk-container-id-4 label.sk-toggleable__label {cursor: pointer;display: block;width: 100%;margin-bottom: 0;padding: 0.3em;box-sizing: border-box;text-align: center;}#sk-container-id-4 label.sk-toggleable__label-arrow:before {content: "▸";float: left;margin-right: 0.25em;color: #696969;}#sk-container-id-4 label.sk-toggleable__label-arrow:hover:before {color: black;}#sk-container-id-4 div.sk-estimator:hover label.sk-toggleable__label-arrow:before {color: black;}#sk-container-id-4 div.sk-toggleable__content {max-height: 0;max-width: 0;overflow: hidden;text-align: left;background-color: #f0f8ff;}#sk-container-id-4 div.sk-toggleable__content pre {margin: 0.2em;color: black;border-radius: 0.25em;background-color: #f0f8ff;}#sk-container-id-4 input.sk-toggleable__control:checked~div.sk-toggleable__content {max-height: 200px;max-width: 100%;overflow: auto;}#sk-container-id-4 input.sk-toggleable__control:checked~label.sk-toggleable__label-arrow:before {content: "▾";}#sk-container-id-4 div.sk-estimator input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-4 div.sk-label input.sk-toggleable__control:checked~label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-4 input.sk-hidden--visually {border: 0;clip: rect(1px 1px 1px 1px);clip: rect(1px, 1px, 1px, 1px);height: 1px;margin: -1px;overflow: hidden;padding: 0;position: absolute;width: 1px;}#sk-container-id-4 div.sk-estimator {font-family: monospace;background-color: #f0f8ff;border: 1px dotted black;border-radius: 0.25em;box-sizing: border-box;margin-bottom: 0.5em;}#sk-container-id-4 div.sk-estimator:hover {background-color: #d4ebff;}#sk-container-id-4 div.sk-parallel-item::after {content: "";width: 100%;border-bottom: 1px solid gray;flex-grow: 1;}#sk-container-id-4 div.sk-label:hover label.sk-toggleable__label {background-color: #d4ebff;}#sk-container-id-4 div.sk-serial::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: 0;}#sk-container-id-4 div.sk-serial {display: flex;flex-direction: column;align-items: center;background-color: white;padding-right: 0.2em;padding-left: 0.2em;position: relative;}#sk-container-id-4 div.sk-item {position: relative;z-index: 1;}#sk-container-id-4 div.sk-parallel {display: flex;align-items: stretch;justify-content: center;background-color: white;position: relative;}#sk-container-id-4 div.sk-item::before, #sk-container-id-4 div.sk-parallel-item::before {content: "";position: absolute;border-left: 1px solid gray;box-sizing: border-box;top: 0;bottom: 0;left: 50%;z-index: -1;}#sk-container-id-4 div.sk-parallel-item {display: flex;flex-direction: column;z-index: 1;position: relative;background-color: white;}#sk-container-id-4 div.sk-parallel-item:first-child::after {align-self: flex-end;width: 50%;}#sk-container-id-4 div.sk-parallel-item:last-child::after {align-self: flex-start;width: 50%;}#sk-container-id-4 div.sk-parallel-item:only-child::after {width: 0;}#sk-container-id-4 div.sk-dashed-wrapped {border: 1px dashed gray;margin: 0 0.4em 0.5em 0.4em;box-sizing: border-box;padding-bottom: 0.4em;background-color: white;}#sk-container-id-4 div.sk-label label {font-family: monospace;font-weight: bold;display: inline-block;line-height: 1.2em;}#sk-container-id-4 div.sk-label-container {text-align: center;}#sk-container-id-4 div.sk-container {/* jupyter's `normalize.less` sets `[hidden] { display: none; }` but bootstrap.min.css set `[hidden] { display: none !important; }` so we also need the `!important` here to be able to override the default hidden behavior on the sphinx rendered scikit-learn.org. See: https://github.com/scikit-learn/scikit-learn/issues/21755 */display: inline-block !important;position: relative;}#sk-container-id-4 div.sk-text-repr-fallback {display: none;}</style><div id="sk-container-id-4" class="sk-top-container"><div class="sk-text-repr-fallback"><pre>LGBMRegressor(n_estimators=450, num_leaves=120, random_state=12345)</pre><b>In a Jupyter environment, please rerun this cell to show the HTML representation or trust the notebook. <br />On GitHub, the HTML representation is unable to render, please try loading this page with nbviewer.org.</b></div><div class="sk-container" hidden><div class="sk-item"><div class="sk-estimator sk-toggleable"><input class="sk-toggleable__control sk-hidden--visually" id="sk-estimator-id-4" type="checkbox" checked><label for="sk-estimator-id-4" class="sk-toggleable__label sk-toggleable__label-arrow">LGBMRegressor</label><div class="sk-toggleable__content"><pre>LGBMRegressor(n_estimators=450, num_leaves=120, random_state=12345)</pre></div></div></div></div></div>




```python
%%time
predictions_valid = model_LGB.predict(features_valid_OE)
```

    Wall time: 704 ms
    


```python
RMSE_valid_LGB = round(mean_squared_error(target_valid, predictions_valid)**0.5)
print('RMSE модели:', RMSE_valid_LGB)
```

    RMSE модели: 1569
    

Составим таблицы для наглядности результатов.


```python
tabledata = [["LinearRegression", "~3.2 s", "~21.4 ms", RMSE_valid_LR],
             ["DecisionTreeRegressor", "~330 ms", "~14 ms", RMSE_valid_DTR],
             ["LightGBM", "~3.53 s", "~658 ms", RMSE_valid_LGB]]
df= pd.DataFrame(tabledata, columns=["Model", "Wall time_train", "Wall time_predict", "RMSE_valid"])
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Model</th>
      <th>Wall time_train</th>
      <th>Wall time_predict</th>
      <th>RMSE_valid</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>LinearRegression</td>
      <td>~3.2 s</td>
      <td>~21.4 ms</td>
      <td>2384</td>
    </tr>
    <tr>
      <th>1</th>
      <td>DecisionTreeRegressor</td>
      <td>~330 ms</td>
      <td>~14 ms</td>
      <td>1867</td>
    </tr>
    <tr>
      <th>2</th>
      <td>LightGBM</td>
      <td>~3.53 s</td>
      <td>~658 ms</td>
      <td>1569</td>
    </tr>
  </tbody>
</table>
</div>



Проверка модели на тестовой выборке.


```python
predictions_valid = model_DTR.predict(features_test_OE)
result = round(mean_squared_error(target_test, predictions_valid)**0.5)
print('RMSE модели:', result)
```

    RMSE модели: 1857
    

**Вывод:** Имея лучшие гиперпараметры, мы обучили модели заново, замерив скорость обучения и скорость предсказаний, а так же качество этих предсказаний. В табличе можете наблюдать результаты. Что касается того, какую модель выбрать, то это `DecisionTreeRegressor`. Если для заказчика важны все три параметра, а заданием была модель, которая выдаёт результат `RMSE менее 2500` то результат очевиден. Результат на тестовой выборке `RMSE = {{result}}`.

## Общий вывод

**Вывод:** В начале работы мы познакомились с данными. И провели предобработку, прежде чем обучать модели. Что именно было сделано:
- переименовали столбцы в привычный нам вид и привели всё к нижнему регистру;
- удалили из таблицы столбцы, которые *точно не понадобятся* нам для обучения моделей. (`date_crawled, registration_month, date_created, number_of_pictures, postal_code, last_seen`);
- было найдены `45040` дубликата и удалены и таблицы;
- в столбце `price` около `12000` продавцов выставили стоимость `0` или очень приближенную к `0`. Поэтому всё, что меньше `500` евро мы убрали из датасете, чтобы они не давали дополнительных искажений при обучении моделей;
- в признаке `vehicle_type` (тип автомобильного кузова) при первичном осмотре данных в этом столбце мы наблюдали `37490 пропуск`. Заполнить категориальный признак в нашем случае мы не имели возможности, но и удалять такое количество данных так же мы не стали. Просто заполнили значением `"other"`;
- по таму же принципу заполнили пропуски значением `"other"` в столбцах `model, fuel_type`. `gearbox` - в этом столбце пропуски заменили на `"unknown"`; 
- а в признаке по ремонту (`repaired`), заменили пропуски у всех машин, что имеют пробег более `120000` на `"yes"`, у другихх на `"no"` соответственно;
- в признаке `registration_year`. Это год регистрации автомобиля. Пропусков не было, но мы заметили разные выбросы в этом столбце. Постоив график, мы приняли решение оставить только годы регистрации `с 1990 по 2016` так как последний год это год выгрузки объявления и создания таблицы;
- `power`. В этом столбце мощность авто (л. с.) мы оставили в датафрейме только те машины, которые укладываются по мощности в диапазон `от 40 до 450`. Были значения и в райне `0`  мы из заменили на медиану по брендам;
- далее мы разбили таблицу на обучающую, валидационную и тестовые выборки. `(60|20|20)`
- у нас `6` категориальных признаков. И так как мы будем обучать разные модели, то для некоторых из них нужно закодировать категориальные признаки как однократный числовой массив. Используем `OneHotEncoder` для линейной модели. А для моеделей решающего дерева будем использовать порядковое кодирование `OrdinalEncoder` (это позволит увеличить скорость обучения).
- после кодирования мы стандартизировали данные для использования их линейной моделью. Сделали это при помощи `StandardScaler`.

Далее мы обучили `3 разные модели` и нашли лучшие гиперпараметры для них.

1 модель `LinearRegression` (RMSE модели: `{{best_score_train_LR}}`)

2 модель `DecisionTreeRegressor` (RMSE модели: `{{best_score_train_DTR}}`) 
- Параметры лучшей модели: {{best_param_train_DTR}}

3 модель `LightGBM` (RMSE модели: `{{best_score_train_LGB}}`) 
- Параметры лучшей модели: {{best_param_train_LGB}}

И уже в конце имея лучшие гиперпараметры, мы обучили модели заново, замерив скорость обучения и скорость предсказаний, а так же качество этих предсказаний. В табличе можете наблюдать результаты. Что касается того, какую модель выбрать, то это `DecisionTreeRegressor`. Если для заказчика важны все три параметра, а заданием была модель, которая выдаёт результат `RMSE менее 2500` и быстрая, то результат очевиден. Результат на тестовой выборке `RMSE = {{result}}`.


```python
tabledata = [["LinearRegression", "~3.2 s", "~21.4 ms", RMSE_valid_LR],
             ["DecisionTreeRegressor", "~330 ms", "~14 ms", RMSE_valid_DTR],
             ["LightGBM", "~3.53 s", "~658 ms", RMSE_valid_LGB]]
df= pd.DataFrame(tabledata, columns=["Model", "Wall time_train", "Wall time_predict", "RMSE_valid"])
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Model</th>
      <th>Wall time_train</th>
      <th>Wall time_predict</th>
      <th>RMSE_valid</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>LinearRegression</td>
      <td>~3.2 s</td>
      <td>~21.4 ms</td>
      <td>2384</td>
    </tr>
    <tr>
      <th>1</th>
      <td>DecisionTreeRegressor</td>
      <td>~330 ms</td>
      <td>~14 ms</td>
      <td>1867</td>
    </tr>
    <tr>
      <th>2</th>
      <td>LightGBM</td>
      <td>~3.53 s</td>
      <td>~658 ms</td>
      <td>1569</td>
    </tr>
  </tbody>
</table>
</div>


